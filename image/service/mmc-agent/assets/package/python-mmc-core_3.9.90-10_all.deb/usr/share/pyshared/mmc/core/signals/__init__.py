from mmc.core.signals.dispatcher import Signal, receiver # pyflakes.ignore
